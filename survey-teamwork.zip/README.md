# survey-teamwork
**Never name the Survey Title in Chinese**
**问卷标题不要用中文**
## website:
#### 1. Directories:
Root Site: E:\Git\survey-teamwork\server\root
>index.html: To view the surveys list.
>index.js: To deal with index.html

>makeSurvey.html: To create and post survey.
>makeSurvey.js: To deal with makeSurvey.js

>custom.css: the common stylesheet

>saveJson.php: To save the json files.

>sendJson.php: To send json files to index.html

>ErrorJson.php: To show errors when Posting failed.

####  2.Interaction with front-end:
> Scan QR code: var fileurl in Function CreateBox in index.js

#### 3. Usage:
index.html: Create->makeSurvey.html: Post->makeSurvey.html:Back to index ->index.html:scan QR code according to the title.
**Never name the Survey Title in Chinese**
**问卷标题不要用中文**